﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using IPT1.Data;
using IPT1.Models;
using IPT1.Controllers;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore;

namespace IPT1.Controllers
{
    public class ApplicantController1 : Controller
    {

        public class IPTcontroller : Controller
        {

            private readonly IPTDBcontext _context;

            private readonly IWebHostEnvironment _webHost;




            public IPTcontroller(IPTDBcontext context, IWebHostEnvironment webHost)
            {
                _context = context;
                _webHost = webHost;

            }
            public IActionResult Index()
            {
                List<Applicant> applicants;
                applicants = _context.Applicants.ToList();
                return View(applicants);
            }


            [HttpGet]
            public IActionResult Create()
            {
                Applicant applicant = new Applicant();
                //applicant.Experiences.Add(new Experience() { ExperienceId = 1 });
                //applicant.Experiences.Add(new Experience() { ExperienceId = 2 });
                //applicant.Experiences.Add(new Experience() { ExperienceId = 3 });
                return View(applicant);
            }

            [HttpPost]
            public IActionResult Create(Applicant applicant)
            {
                applicant.Experiences.RemoveAll(n => n.YearsWorked == 0);


                foreach (Experience experience in applicant.Experiences)
                {
                    if (experience.CompanyName == null || experience.CompanyName.Length == 0)
                        applicant.Experiences.Remove(experience);

                }

                //  string uniqueFileName = GetUploadedFileName(applicant);
                // applicant.PhotoUrl = uniqueFileName;

                _context.Add(applicant);
                _context.SaveChanges();
                return RedirectToAction("index");


            }








        }
    }
}
