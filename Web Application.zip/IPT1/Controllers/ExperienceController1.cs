﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using IPT1.Data;
using IPT1.Models;
using IPT1.Controllers;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore;

namespace IPT1.Controllers
{
    public class ExperienceController1 : Controller
    {

        public ExperienceController1()
        {
            int Name;
            int Age;

        }



        private readonly IPTDBcontext _context;

        private readonly IWebHostEnvironment _webHost;



        public IActionResult Index()
        {
            List<Applicant> applicants;
            applicants = _context.Applicants.ToList();
            return View(applicants);
            
        }




        public IActionResult Details(int Id)
        {
            Applicant applicant = _context.Applicants
                .Include(e => e.Experiences)
                .Where(a => a.Id == Id).FirstOrDefault();

            return View(applicant);
        }

       

        

        // GET: ExperienceController1/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ExperienceController1/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ExperienceController1/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }





        [HttpPost]
        public IActionResult Edit(Applicant applicant)
        {

           //Experience> stockmaster = new StockMaster();

           // stockmaster.ItemCode = "rg";

           // stockmaster.ItemName = "Register";

           // stockmaster.Rate = 20;

           // stockmaster.Stock = 12;




            List<Experience> expDetails = _context.Experiences.Where(d => d.ApplicantId == applicant.Id).ToList();
            _context.Experiences.RemoveRange(expDetails);
            _context.SaveChanges();


            applicant.Experiences.RemoveAll(n => n.YearsWorked == 0);




            //  string uniqueFileName = GetUploadedFileName(applicant);
            // applicant.PhotoUrl = uniqueFileName;

            _context.Attach(applicant);
            _context.Entry(applicant).State = EntityState.Modified;
            _context.Experiences.AddRange(applicant.Experiences);
            _context.SaveChanges();
            return RedirectToAction("index");


        }








        //// POST: ExperienceController1/Edit/5
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Edit(int id,string name,string age, IFormCollection collection)
        //{
        //    try
        //    {
        //        Applicant userData = _context.Applicants.Where(u => u.Id == id).SingleOrDefault();
        //        userData.Name = name;
        //       // userData.Email = user.Email;
        //        userData.Age = age;
        //        _context.SubmitChanges();


        //        return RedirectToAction(nameof(Index));
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}

        // GET: ExperienceController1/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: ExperienceController1/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
