﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Services.Description;
using System.Windows.Forms;
using System.Xml.Linq;
using PayRoll_GUI.ClassScripts;
using PayRoll_GUI.WBService;

namespace PayRoll_GUI
{
    public partial class Form1 : Form
    {
        public List<Panel> Menus = new List<Panel>();


       // string connstring = "";
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-VLNDB2V;Initial Catalog=IPT;Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader read;
        string id;
        bool Mode = true;
        string sql;
        // con.Open();




       


         WBService.WebService1 wbservice = new WBService.WebService1();

       






        public Form1()
        {
            InitializeComponent();
            Menus.Add(pnlAddEmployee);
            Menus.Add(pnlRemoveEmployee);
            Menus.Add(pnlDisplayEmployees);
            Menus.Add(pnlAddAddress);
           // DisplayEmployees();
        }

        void HideAllMenus()
        {
            foreach (var menu in Menus)
            {
                menu.Visible = false;
            }
        }


        //Loads a given Menu
        private void LoadAddEmployeeMenu(object sender, EventArgs e)
        {
            HideAllMenus();
            pnlAddEmployee.Visible = true;
        }
        private void LoadRemoveEmployeeMenu(object sender, EventArgs e)
        {
            HideAllMenus();
            pnlRemoveEmployee.Visible = true;
        }

        private void LoadAddAddressMenu(object sender, EventArgs e)
        {
            HideAllMenus();
            pnlAddAddress.Visible = true;
        }
        private void LoadDisplayEmployeesMenu(object sender, EventArgs e)
        {
            HideAllMenus();
            pnlDisplayEmployees.Visible = true;
            DisplayEmployees();
        }

        /// <summary>
        /// checks the added employee to see if there is someone with that name on the payroll and if there is updates the data instead
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// 




       



        private void ConfirmNewEmployeeData(object sender, EventArgs e)
        {
            long intConv = 0;
            Int64.TryParse(txbAppNum.Text, out intConv);
            int AppNum = (int)intConv;
            Int64.TryParse(txbZip.Text, out intConv);
            int ZIP = (int)intConv;

            Address newAddress = new Address(txbAdress.Text, AppNum, txbCity.Text, txbState.Text, ZIP);

            int PhoneNumber = (int)intConv;
            float Wage = 0;
            float HoursWorked = 0;
            float.TryParse(txbWage.Text, out Wage);
            float.TryParse(txbHoursWorked.Text, out HoursWorked);

            Employee newEmployee = new Employee(txbFirstName.Text, txblastName.Text, PhoneNumber, newAddress, txbJobTitle.Text, Wage, HoursWorked, chbOnPayroll.Checked);
            Program.PayRoll.Add(newEmployee);
            lblConfirmText.Text = txbFirstName.Text+" "+ txblastName.Text + " was added to the payroll" ;


          
       //    string query = "Select * from person" 


            string name     = txbFirstName.Text + " " + txblastName.Text;
            string gender = "Male" ;
            string age = txbState.Text ;
            string job_status = txbJobTitle.Text;
            string work_per_hour = txbHoursWorked.Text;
            string wage = txbWage.Text;
            string exp = txbHoursWorked.Text;
            int wages;
            int works;
            Int32.TryParse(wage, out wages);
            Int32.TryParse(work_per_hour,out works);

                //     if (Mode = true)
                //   {
                sql = "insert into Applicants(Name,Gender,Age,Job_Status,work_per_hour,Wage,TotalExperience) values (@Name,@Gender,@Age,@Job_Status,@work_per_hour,@Wage,@TotalExperience )";
                con.Open();
                cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@Name", name);
                cmd.Parameters.AddWithValue("@Gender", gender);
                cmd.Parameters.AddWithValue("@Age", age);
                cmd.Parameters.AddWithValue("@Job_Status", job_status);
                cmd.Parameters.AddWithValue("@work_per_hour", work_per_hour);
                cmd.Parameters.AddWithValue("@Wage", wage);
                cmd.Parameters.AddWithValue("@TotalExperience", exp);



                MessageBox.Show("Record Addddddd");




            int x = wbservice.Salary(wages,works);
            MessageBox.Show("Salary = " + x);


            





           // MessageBox.Show(WBService.Salary());
                cmd.ExecuteNonQuery();
                txbFirstName.Clear();
                txblastName.Clear();
                txbWage.Clear();
                txbZip.Clear();
                txbState.Clear();
                txbPhoneNum.Clear();
                txbJobTitle.Clear();
                txbHoursWorked.Clear();
                txbCity.Clear();
                txbJobTitle.Clear();
          //  }
            //else
            //{
                 
            //        id = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            //        sql = "update student set stname = @stname, course= @course,fee = @fee where id = @id";
            //        con.Open();
            //        cmd = new SqlCommand(sql, con);
            //        cmd.Parameters.AddWithValue("@stname", name);
            //        cmd.Parameters.AddWithValue("@course", course);
            //        cmd.Parameters.AddWithValue("@fee", fee);
            //        cmd.Parameters.AddWithValue("@id", id);
            //        MessageBox.Show("Record Updateddddd");
            //        cmd.ExecuteNonQuery();

            //        txbFirstName.Clear();
            //        txblastName.Clear();
            //        txbWage.Clear();
            //        txbZip.Clear();
            //        txbState.Clear();
            //        txbPhoneNum.Clear();
            //        txbJobTitle.Clear();
            //        txbHoursWorked.Clear();
            //        txbCity.Clear();
            //        txbJobTitle.Clear();
            //        button1.Text = "Save";
            //        Mode = true;

                
            //}


            con.Close();






        }


        /// <summary>
        /// checks to see if there is a  employee by that name and removes them if there is one
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RemoveEmployee(object sender, EventArgs e)
        {
            foreach (var employee in Program.PayRoll)
            {
                if(employee.FirstName == txbRemoveFirstName.Text &&employee.LastName == txbRemoveLastName.Text)
                {
                    Program.PayRoll.Remove(employee);
                    lblConfirmRemove.Text = employee.FirstName + " " +employee.LastName + " was successfully removed from the payroll";
                    return;
                }
            }

            lblConfirmRemove.Text = "that employee does not exist";

        }

        /// <summary>
        /// Displays all the employees on the payroll
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DisplayEmployees()
        {    
            DataTable dataTable = new DataTable("Employees");
            dataTable.Clear();
            //MessageBox.Show("DONE5");
            dataTable.Columns.Add("ID", typeof(int));
            dataTable.Columns.Add("Name", typeof(String));
            dataTable.Columns.Add("Gender", typeof(String));
            dataTable.Columns.Add("Age", typeof(int));
          //  dataTable.Columns.Add("LastName", typeof(String));
            dataTable.Columns.Add("Job Status", typeof(String));
            dataTable.Columns.Add("Hours Worked", typeof(float));
            dataTable.Columns.Add("Wage", typeof(float));
            dataTable.Columns.Add("Total Experience", typeof(float));
            
            //foreach (var employee in Program.PayRoll)
            //{
            //    DataRow row = dataTable.NewRow();
            //    row["Firstname"] = employee.FirstName;
            //    row["LastName"] = employee.LastName;
            //    row["JobTitle"] = employee.JobTitle;
            //    row["Hours Worked"] = employee.HoursWorked;
            //    row["Wage"] = employee.Wage;
            //    dataTable.Rows.Add(row);
            //}
            try
            {
                sql = "select * from Applicants";
              //  MessageBox.Show("DONE1");
                cmd = new SqlCommand(sql, con);
               // MessageBox.Show("DONE2");
                con.Open();
               // MessageBox.Show("DONE3");
                read = cmd.ExecuteReader();
                //MessageBox.Show("DONE4");
                dataTable.Rows.Clear();
              //  MessageBox.Show("DONE5");
                while (read.Read())
                {
                   // MessageBox.Show("DONE6");
                    // DataRow row = dataTable.NewRow();
                    // dataTable.Rows.Add(read[0], read[1], read[2], read[3], read[4], read[5], read[6], read[7]);

                    DataRow row = dataTable.NewRow();
                    row["ID"] = read[0];
                    row["Name"] = read[1];
                    row["Gender"] = read[2];
                    row["Age"] = read[3];
                    row["Job Status"] = read[4];
                    row["Hours Worked"] = read[5];
                    row["Wage"] = read[6];
                    row["Total Experience"] = read[7];
                    dataTable.Rows.Add(row);



                   // MessageBox.Show("DONE");
                }
                con.Close();
            }
            catch(Exception ex) 
            {
                MessageBox.Show(ex.Message);
            }

            grdEmployeeData.DataSource = dataTable;
          

        }

        private void PayEmployees(object sender, EventArgs e)
        {
            lblPayEmployees.Text = "You Paid :" + Program.PayEmployees();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pnlAddAddress_Paint(object sender, PaintEventArgs e)
        {

        }

        private void grdEmployeeData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
